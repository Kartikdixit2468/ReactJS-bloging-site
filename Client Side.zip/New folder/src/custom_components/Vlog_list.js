import React from 'react'

function Vlog_list() {
  return (
    <div>Vlog_list</div>
  )
}

export default Vlog_list