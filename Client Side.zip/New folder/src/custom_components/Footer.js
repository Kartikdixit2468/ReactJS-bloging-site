import React from 'react'
import '../css/App.css'
function Footer() {
  return (
    <footer> <h6> &copy; BY ANONYMOUS  |  All Rights Reserved</h6></footer>

  
  )
}

export default Footer