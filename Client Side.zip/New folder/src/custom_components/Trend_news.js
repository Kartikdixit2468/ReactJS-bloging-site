import React from 'react'

function Trend_news() {
  return (
    <div>Trend_news</div>
  )
}

export default Trend_news
