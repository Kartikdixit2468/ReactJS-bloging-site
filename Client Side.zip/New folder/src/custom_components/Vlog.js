import React from 'react'

function Vlog() {
  return (
    <div>Vlog</div>
  )
}

export default Vlog