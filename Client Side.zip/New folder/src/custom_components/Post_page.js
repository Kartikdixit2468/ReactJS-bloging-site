import React from 'react'

function Post_page() {
  return (
    <div>Post_page</div>
  )
}

export default Post_page